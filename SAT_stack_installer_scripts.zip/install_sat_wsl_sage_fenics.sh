#!/usr/bin/env bash
set -e

echo "============================================================"
echo "SAT WSL Installer: Miniforge + Sage + FEniCSx"
echo "============================================================"

if ! command -v curl >/dev/null 2>&1; then
  echo "Installing curl/build basics..."
  sudo apt update
  sudo apt install -y build-essential curl git wget
fi

if [ ! -d "$HOME/miniforge3" ]; then
  echo "Downloading Miniforge for WSL/Linux..."
  curl -L -O "https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-$(uname)-$(uname -m).sh"
  bash "Miniforge3-$(uname)-$(uname -m).sh" -b -p "$HOME/miniforge3"
fi

source "$HOME/miniforge3/bin/activate"

conda config --add channels conda-forge || true
conda config --set channel_priority strict

echo "Creating sat-sage..."
if ! conda env list | grep -q '^sat-sage '; then
  mamba create -n sat-sage -c conda-forge -y sage python=3.12 jupyterlab ipykernel
else
  echo "sat-sage already exists; skipping create."
fi

mamba run -n sat-sage python -m ipykernel install --user --name sat-sage --display-name "SageMath (SAT Sage)"
mamba run -n sat-sage sage -c "print('sat-sage OK'); print(factor(2026))"

echo "Creating sat-pde..."
if ! conda env list | grep -q '^sat-pde '; then
  mamba create -n sat-pde -c conda-forge -y python=3.12 fenics-dolfinx mpich pyvista matplotlib jupyterlab ipykernel
else
  echo "sat-pde already exists; skipping create."
fi

mamba run -n sat-pde python -m ipykernel install --user --name sat-pde --display-name "Python (SAT PDE / FEniCSx)"
mamba run -n sat-pde python -c "import dolfinx; print('sat-pde / FEniCSx OK')"

mamba clean --all -y

echo "Done."
