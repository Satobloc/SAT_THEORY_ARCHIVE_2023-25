CONTINUOUS WHIRLIGIG V1

This build uses analytic input curves A(alpha) and B(beta).
No stored curve vertices are used by the mechanism itself.

Continuous laws:
psi(tau) = tau
s(tau) = -((R + rb)/rb) psi(tau)
alpha(tau) = 9 tau + 0.15 sin(2 tau)
beta(tau) = -13 tau + 0.22 sin(3 tau) + 0.7
phi(tau) = 17.0 tau

Ball orientation:
Q(tau) = F_world(psi) F_body(s)^T

Connector:
L(tau,lambda) = (1-lambda)a(tau) + lambda b(tau)

The connector-normal frame is parallel transported.
The pen rotates at constant angular rate about the connector.
The drawn point is the continued positive ray/torus intersection.

Finite evaluation points are used only to solve and render the
continuous construction.
