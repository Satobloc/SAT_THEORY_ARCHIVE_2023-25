Current continuous spectral Navier–Stokes Whirligig solver source.

Run:
    python continuous_ns_whirligig_solver.py

Quick non-animation check:
    python continuous_ns_whirligig_solver.py --no-animation --n-eval 2000

The solver is the pre-minimum-curvature version. It freezes the current
Whirligig mechanics and uses the original V1 traversal laws.
