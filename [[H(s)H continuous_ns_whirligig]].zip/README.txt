CONTINUOUS SPECTRAL NAVIER–STOKES WHIRLIGIG

The rigid Whirligig mechanics are unchanged from continuous_whirligig_v1.
Only the two body-fixed input curves were replaced.

INPUT FIELDS
A(x,y,z) = (sin z, 0, 0)

B_epsilon(x,y,z) =
    (-sin y/D, sin x/D, 0)
D = epsilon^2 + 2 - cos x - cos y
epsilon = 0.35

CONTINUOUS ENCODING
The existing mathematical object used is a sparse Fourier representation.

Each nonzero complex 3-D rFFT coefficient c_j is assigned to one harmonic:
    Re(c_j) -> cosine amplitude
    Im(c_j) -> sine amplitude

The resulting finite trigonometric polynomial is continuous on S^1.
An invertible tanh latitude map places it on the ball.

A retained coefficients: 1
B retained coefficients: 240

RECONSTRUCTION
A relative field error: 2.123e-16
B relative field error: 5.276e-16

MECHANICS
- annulus-controlled rolling
- original V1 alpha(tau) and beta(tau) traversal laws
- continuous connector
- Bishop/parallel-transport frame
- constant pen rotation
- first forward ray intersection with the fixed torus wall

LIMITATION
B_epsilon is a smooth regularized candidate field. It is not asserted to be
the Navier–Stokes evolution of A. This build tests the encoding and continuous
geometric composition.
