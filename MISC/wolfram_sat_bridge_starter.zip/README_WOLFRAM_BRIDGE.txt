WOLFRAM|ALPHA → SAT BRIDGE
===========================

PURPOSE

This is a small, conservative wrapper around the Wolfram|Alpha Full Results
API. It is designed for calculation checks, unit conversions, symbolic/numeric
spot checks, input-interpretation inspection, and SAT audit work.

It does not turn the Full Results API into a remote Mathematica kernel.
Large custom derivations should be performed in a Wolfram notebook/Wolfram
Language session, with the API used as a narrower computational witness.


SETUP ON WINDOWS 10

1. Open PowerShell in this folder.

2. Install the only dependency:

   py -m pip install requests

3. Either set your AppID for the current PowerShell session:

   $env:WOLFRAM_APPID = "PASTE-YOUR-APPID-HERE"

   Or leave it unset. The program will request the AppID through a hidden
   prompt each time it starts.

4. Run the smoke tests:

   py wolfram_bridge.py --smoke-test

5. Run an individual query:

   py wolfram_bridge.py "hbar c / (1 meV)"

6. Inspect all returned plaintext pods:

   py wolfram_bridge.py --all-pods "solve y'' + omega^2 y = 0"

7. Obtain normalized JSON for program-to-program use:

   py wolfram_bridge.py --json "eigenvalues of [[2,1],[1,2]]"


SECURITY

- Do not paste the AppID into ChatGPT, email, screenshots, shared documents,
  source code, or a public repository.
- The wrapper never prints or saves the AppID.
- If you later place the AppID in a .env file, add .env to .gitignore.
- Revoke and replace the AppID through the Wolfram developer portal if it is
  ever exposed.


RECOMMENDED SAT ROLE

Treat Wolfram output as a computational witness, not as an authority and not
as an independent replication of calculations performed in Wolfram notebooks.

For every consequential calculation:

A. State the expression, variables, domains, units, and assumptions explicitly.
B. Inspect Wolfram|Alpha's "Input interpretation" and assumption metadata.
C. Reject or rerun ambiguous queries rather than silently accepting them.
D. Reproduce the result with Python/SymPy, mpmath, numerical integration, or
   another genuinely separate route.
E. For foundational claims, move the final statement into Lean or another
   formal specification when feasible.
F. Record the query and your own audit verdict, rather than building a cache
   of raw Wolfram content.


GOOD FIRST SAT TESTS

- Unit and scale checks:
    hbar c / (1 meV)
    Compton wavelength of 1 meV/c^2

- Exact/numeric comparison:
    numerical value of 3/(4 pi)
    continued fraction of 0.238732414637843

- Hessian and characteristic-polynomial checks:
    Hessian of f(x,y)=a x^2 + 2 b x y + c y^2
    determinant of [[a-lambda,b],[b,c-lambda]]

- Series and asymptotics:
    series expansion of 1-cos(x) around x=0 through order 8

Start with explicit scalar or matrix examples. Wolfram|Alpha's natural-language
parser is not a safe place to introduce the full SAT notation all at once.
