#!/usr/bin/env python3
"""
Minimal Wolfram|Alpha Full Results API bridge for SAT calculation/audit work.

The AppID is read from WOLFRAM_APPID or requested through a hidden prompt.
It is never written to disk or included in printed output.
"""

from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
from dataclasses import dataclass
from typing import Any
from urllib.parse import quote_plus

import requests


API_URL = "https://api.wolframalpha.com/v2/query"
PUBLIC_RESULT_URL = "https://www.wolframalpha.com/input?i={query}"


class WolframAPIError(RuntimeError):
    """Raised when the Wolfram|Alpha API cannot return a usable response."""


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _redact(text: str, secret: str) -> str:
    return text.replace(secret, "[REDACTED]") if secret else text


@dataclass
class WolframAlphaClient:
    appid: str
    timeout_seconds: float = 35.0
    units: str = "metric"

    @classmethod
    def from_environment(cls) -> "WolframAlphaClient":
        appid = os.getenv("WOLFRAM_APPID", "").strip()
        if not appid:
            appid = getpass.getpass("Wolfram|Alpha AppID (hidden): ").strip()
        if not appid:
            raise WolframAPIError("No AppID supplied.")
        return cls(appid=appid)

    def query(
        self,
        input_text: str,
        *,
        assumptions: list[str] | None = None,
        include_pod_ids: list[str] | None = None,
    ) -> dict[str, Any]:
        query = input_text.strip()
        if not query:
            raise ValueError("The query cannot be empty.")

        params: list[tuple[str, str]] = [
            ("appid", self.appid),
            ("input", query),
            ("output", "json"),
            ("format", "plaintext"),
            ("units", self.units),
        ]

        for assumption in assumptions or []:
            params.append(("assumption", assumption))
        for pod_id in include_pod_ids or []:
            params.append(("includepodid", pod_id))

        try:
            response = requests.get(API_URL, params=params, timeout=self.timeout_seconds)
        except requests.RequestException as exc:
            raise WolframAPIError(
                "Network request failed: " + _redact(str(exc), self.appid)
            ) from None

        if response.status_code != 200:
            raise WolframAPIError(
                f"Wolfram|Alpha returned HTTP {response.status_code}."
            )

        try:
            payload = response.json()
        except ValueError:
            raise WolframAPIError("The API response was not valid JSON.") from None

        return self._normalize(query, payload)

    def _normalize(self, query: str, payload: dict[str, Any]) -> dict[str, Any]:
        qr = payload.get("queryresult", {})
        api_error = qr.get("error")

        if isinstance(api_error, dict):
            error_detail = api_error
            is_error = True
        else:
            error_detail = {}
            is_error = bool(api_error)

        pods: list[dict[str, Any]] = []
        for pod in _as_list(qr.get("pods")):
            texts: list[str] = []
            for subpod in _as_list(pod.get("subpods")):
                plaintext = subpod.get("plaintext")
                if isinstance(plaintext, str) and plaintext.strip():
                    texts.append(plaintext.strip())

            pods.append(
                {
                    "id": pod.get("id"),
                    "title": pod.get("title"),
                    "primary": bool(pod.get("primary", False)),
                    "scanner": pod.get("scanner"),
                    "texts": texts,
                }
            )

        assumptions: list[dict[str, Any]] = []
        assumptions_root = qr.get("assumptions", {})
        for item in _as_list(
            assumptions_root.get("assumptions")
            if isinstance(assumptions_root, dict)
            else assumptions_root
        ):
            values = []
            for value in _as_list(item.get("values")):
                values.append(
                    {
                        "name": value.get("name"),
                        "description": value.get("desc"),
                        "input": value.get("input"),
                    }
                )
            assumptions.append(
                {
                    "type": item.get("type"),
                    "word": item.get("word"),
                    "template": item.get("template"),
                    "values": values,
                }
            )

        warnings: list[str] = []
        if qr.get("timedout"):
            warnings.append(f"Scanners timed out: {qr['timedout']}")
        if qr.get("timedoutpods"):
            warnings.append(f"Pods timed out: {qr['timedoutpods']}")
        if qr.get("parsetimedout"):
            warnings.append("Input parsing timed out.")
        if assumptions:
            warnings.append("Wolfram|Alpha made one or more assumptions; inspect them.")

        normalized = {
            "query": query,
            "success": bool(qr.get("success", False)),
            "error": is_error,
            "error_detail": error_detail,
            "timing_seconds": qr.get("timing"),
            "datatypes": qr.get("datatypes"),
            "warnings": warnings,
            "assumptions": assumptions,
            "pods": pods,
            "best_answer": self._best_answer(pods),
            "wolframalpha_result_page": PUBLIC_RESULT_URL.format(
                query=quote_plus(query)
            ),
        }
        return normalized

    @staticmethod
    def _best_answer(pods: list[dict[str, Any]]) -> dict[str, Any] | None:
        priority_ids = {
            "Result",
            "ExactResult",
            "DecimalApproximation",
            "Solution",
            "Solutions",
        }

        candidates = [
            pod for pod in pods if pod["primary"] and pod["texts"]
        ]
        if not candidates:
            candidates = [
                pod for pod in pods if pod["id"] in priority_ids and pod["texts"]
            ]
        if not candidates:
            candidates = [pod for pod in pods if pod["texts"]]

        if not candidates:
            return None

        pod = candidates[0]
        return {
            "pod_id": pod["id"],
            "title": pod["title"],
            "text": "\n".join(pod["texts"]),
        }


SMOKE_TESTS = [
    "integrate exp(-x^2) from -infinity to infinity",
    "eigenvalues of [[2,1],[1,2]]",
    "hbar c / (1 meV)",
]


def print_human(result: dict[str, Any], show_all: bool = False) -> None:
    print(f"\nQuery: {result['query']}")
    print(f"Success: {result['success']}")

    answer = result.get("best_answer")
    if answer:
        print(f"Answer [{answer['title']}]:")
        print(answer["text"])
    else:
        print("No primary textual answer was returned.")

    if result["warnings"]:
        print("\nWarnings:")
        for warning in result["warnings"]:
            print(f"- {warning}")

    if result["assumptions"]:
        print("\nAssumptions:")
        for assumption in result["assumptions"]:
            label = assumption.get("word") or assumption.get("type") or "unknown"
            print(f"- {label}")
            for value in assumption.get("values", []):
                marker = value.get("description") or value.get("name")
                if marker:
                    print(f"  - {marker}")

    if show_all:
        print("\nAll textual pods:")
        for pod in result["pods"]:
            if not pod["texts"]:
                continue
            print(f"\n[{pod['id']}] {pod['title']}")
            for text in pod["texts"]:
                print(text)

    print("\nWolfram|Alpha result page:")
    print(result["wolframalpha_result_page"])


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Query the Wolfram|Alpha Full Results API safely."
    )
    parser.add_argument("query", nargs="*", help="Natural-language query")
    parser.add_argument(
        "--smoke-test",
        action="store_true",
        help="Run three basic API validation queries.",
    )
    parser.add_argument(
        "--all-pods",
        action="store_true",
        help="Display every returned plaintext pod.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print normalized JSON instead of a human-readable report.",
    )
    args = parser.parse_args()

    try:
        client = WolframAlphaClient.from_environment()

        if args.smoke_test:
            queries = SMOKE_TESTS
        elif args.query:
            queries = [" ".join(args.query)]
        else:
            parser.error("Provide a query or use --smoke-test.")

        for query in queries:
            result = client.query(query)
            if args.json:
                print(json.dumps(result, indent=2, ensure_ascii=False))
            else:
                print_human(result, show_all=args.all_pods)

        return 0
    except (WolframAPIError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
